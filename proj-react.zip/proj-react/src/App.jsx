import './App.css';

import { Login } from './assets/Login';

function App(){
  return (
    <div>
      <Login />
      <Login/>
    </div>
  );
}

export default App;
